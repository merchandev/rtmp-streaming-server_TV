#!/bin/sh
set -eu

HLS_DIR="${HLS_DIR:-/tmp/hls}"
SSL_DOMAIN="${SSL_DOMAIN:-tv.monagasvision.com}"
LE_CERT_DIR="${LE_CERT_DIR:-/etc/letsencrypt/live/${SSL_DOMAIN}}"
DEFAULT_CERT="${DEFAULT_CERT:-/etc/nginx/ssl/nginx.crt}"
DEFAULT_KEY="${DEFAULT_KEY:-/etc/nginx/ssl/nginx.key}"
RUNTIME_SSL_DIR="${RUNTIME_SSL_DIR:-/run/nginx-ssl}"
RUNTIME_CERT="${RUNTIME_SSL_DIR}/tls.crt"
RUNTIME_KEY="${RUNTIME_SSL_DIR}/tls.key"

mkdir -p "$HLS_DIR" "$RUNTIME_SSL_DIR"
chmod 777 "$HLS_DIR"

if [ -f "${LE_CERT_DIR}/fullchain.pem" ] && [ -f "${LE_CERT_DIR}/privkey.pem" ]; then
    ln -sf "${LE_CERT_DIR}/fullchain.pem" "$RUNTIME_CERT"
    ln -sf "${LE_CERT_DIR}/privkey.pem" "$RUNTIME_KEY"
    echo "Using Let's Encrypt certificate from ${LE_CERT_DIR}"
elif [ -f "$DEFAULT_CERT" ] && [ -f "$DEFAULT_KEY" ]; then
    ln -sf "$DEFAULT_CERT" "$RUNTIME_CERT"
    ln -sf "$DEFAULT_KEY" "$RUNTIME_KEY"
    echo "Let's Encrypt certificate not found. Falling back to bundled certificate files."
else
    echo "No SSL certificate files were found." >&2
    exit 1
fi

echo "Starting Nginx Wrapper..."
exec nginx -g "daemon off;"
